#!/usr/bin/env python3
# A simple, dependency-free Python monitoring server demonstrating dynamic htmz swaps.
# Run this with: python3 server.py

from http.server import HTTPServer, SimpleHTTPRequestHandler
import subprocess
import os

PORT = 8080

class MonitoringHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        # Intercept the dynamic /disk-space route
        if self.path.startswith("/disk-space"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            
            try:
                # Run the system command df -h
                output = subprocess.check_output(["df", "-h"]).decode("utf-8")
                
                # Wrap it directly in the targeted HTML fragment
                fragment = f"""
                <div id="dynamic-panel">
                    <h3>Server Disk Space Metrics</h3>
                    <pre>{output}</pre>
                    <a href="/disk-space#dynamic-panel" target="htmz" class="btn">Refresh Disk Space</a>
                </div>
                """
            except Exception as e:
                fragment = f'<div id="dynamic-panel"><p style="color:red;">Error running command: {e}</p></div>'
                
            self.wfile.write(fragment.encode("utf-8"))
        else:
            # Serve index.html or other static files normally
            super().do_GET()

if __name__ == "__main__":
    print(f"Starting server on http://localhost:{PORT}")
    print("Press Ctrl+C to stop.")
    server = HTTPServer(("127.0.0.1", PORT), MonitoringHandler)
    server.serve_forever()
